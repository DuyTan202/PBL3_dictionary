﻿
namespace PBL3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btTu = new System.Windows.Forms.Button();
            this.btDich = new System.Windows.Forms.Button();
            this.btTra = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btLS = new System.Windows.Forms.Button();
            this.btExit = new System.Windows.Forms.Button();
            this.btShow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btTu
            // 
            this.btTu.BackColor = System.Drawing.Color.White;
            this.btTu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTu.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTu.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btTu.Location = new System.Drawing.Point(33, 224);
            this.btTu.Name = "btTu";
            this.btTu.Size = new System.Drawing.Size(143, 42);
            this.btTu.TabIndex = 20;
            this.btTu.Text = "Từ Của Bạn";
            this.btTu.UseVisualStyleBackColor = false;
            this.btTu.Click += new System.EventHandler(this.btTu_Click);
            // 
            // btDich
            // 
            this.btDich.BackColor = System.Drawing.Color.White;
            this.btDich.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDich.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDich.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btDich.Location = new System.Drawing.Point(260, 132);
            this.btDich.Name = "btDich";
            this.btDich.Size = new System.Drawing.Size(141, 42);
            this.btDich.TabIndex = 19;
            this.btDich.Text = "Dịch Văn Bản";
            this.btDich.UseVisualStyleBackColor = false;
            this.btDich.Click += new System.EventHandler(this.btDich_Click);
            // 
            // btTra
            // 
            this.btTra.BackColor = System.Drawing.Color.White;
            this.btTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTra.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTra.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btTra.Location = new System.Drawing.Point(33, 132);
            this.btTra.Name = "btTra";
            this.btTra.Size = new System.Drawing.Size(141, 42);
            this.btTra.TabIndex = 18;
            this.btTra.Text = "Tra Từ";
            this.btTra.UseVisualStyleBackColor = false;
            this.btTra.Click += new System.EventHandler(this.btTra_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(30, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "Chức Năng Thực Hiện:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(95, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 27);
            this.label1.TabIndex = 16;
            this.label1.Text = "Từ Điển Anh - Việt";
            // 
            // btLS
            // 
            this.btLS.BackColor = System.Drawing.Color.White;
            this.btLS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLS.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLS.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btLS.Location = new System.Drawing.Point(260, 224);
            this.btLS.Name = "btLS";
            this.btLS.Size = new System.Drawing.Size(141, 42);
            this.btLS.TabIndex = 21;
            this.btLS.Text = "Từ Đã Tra";
            this.btLS.UseVisualStyleBackColor = false;
            this.btLS.Click += new System.EventHandler(this.btLS_Click);
            // 
            // btExit
            // 
            this.btExit.BackColor = System.Drawing.Color.White;
            this.btExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExit.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExit.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btExit.Location = new System.Drawing.Point(78, 385);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(279, 42);
            this.btExit.TabIndex = 21;
            this.btExit.Text = "EXIT";
            this.btExit.UseVisualStyleBackColor = false;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btShow
            // 
            this.btShow.BackColor = System.Drawing.Color.White;
            this.btShow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btShow.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btShow.ForeColor = System.Drawing.Color.Black;
            this.btShow.Location = new System.Drawing.Point(144, 311);
            this.btShow.Name = "btShow";
            this.btShow.Size = new System.Drawing.Size(159, 42);
            this.btShow.TabIndex = 22;
            this.btShow.Text = "Trang Cá Nhân";
            this.btShow.UseVisualStyleBackColor = false;
            this.btShow.Click += new System.EventHandler(this.btShow_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 442);
            this.Controls.Add(this.btShow);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.btLS);
            this.Controls.Add(this.btTu);
            this.Controls.Add(this.btDich);
            this.Controls.Add(this.btTra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Chức Năng User";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btTu;
        private System.Windows.Forms.Button btDich;
        private System.Windows.Forms.Button btTra;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btLS;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btShow;
    }
}