﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3.DTO
{
    class User
    {
        public string ID_User { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Phone_Number { get; set; }
        public string Address_User { get; set; }
        public string User_PW { get; set; }
        public static bool ID_tang(User s1, User s2)
        {
            if (Convert.ToInt32(s1.ID_User) > Convert.ToInt32(s2.ID_User))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool ID_giam(User s1, User s2)
        {
            if (Convert.ToInt32(s1.ID_User) < Convert.ToInt32(s2.ID_User))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool Name_Tang(User s1, User s2)
        {
            if (string.Compare(s1.UserName, s2.UserName) > 0)
            {
                return true;
            }
            else
                return false;
        }
        public static bool Name_Giam(User s1, User s2)
        {
            if (string.Compare(s1.UserName, s2.UserName) < 0)
            {
                return true;
            }
            else
                return false;
        }
    }
}
