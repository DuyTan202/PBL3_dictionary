﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3.DTO
{
    class Admin
    {
        public string ID_Admin { get; set; }
        public string AdminName { get; set; }
        public string Email { get; set; }
        public string Phone_Number { get; set; }
        public string Address_Admin { get; set; }
        public string Admin_PW { get; set; }
    }
}
