﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace PBL3.DAL
{
    class DBhelper
    {
        private SqlConnection cnn;
        private static DBhelper _Instance;
        public static  DBhelper Instance
        {
            get
            {
                if (_Instance == null)
                {
                    string cmt = @"Data Source = DESKTOP-9MMHKPO\SQLEXPRESS; Initial Catalog = PBL3; Integrated Security = True; ";
                    _Instance = new DBhelper(cmt);
                }
                return _Instance;
            }
            private set
            {

            }
        }
        private DBhelper(string s)
        {
            cnn = new SqlConnection(s);
        }
        public void ExecuteDB(string query)
        {
            SqlCommand cmd = new SqlCommand(query, cnn);
            cnn.Open();
            cmd.ExecuteNonQuery();
            cnn.Close();
        }        
        public DataTable GetRecords1(string query)
        {          
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, cnn);
            cnn.Open();           
            da.Fill(dt);
            cnn.Close();          
            return dt;
        }
    }    
}
